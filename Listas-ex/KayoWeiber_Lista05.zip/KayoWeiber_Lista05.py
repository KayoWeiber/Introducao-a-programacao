'''#ex01
varGlo=15
def multi(num):
    global res
    res=num*varGlo
multi(int(input("Digite um número:")))
print(res)


#ex02
def numero(num):
    x=num
    print(f"O número digitado é:{x}")

numero(int(input("Digite um número:")))

#ex03
def funct(lista,troca):
    print(f"Os elementos da lista são:")
    for i in lista:
        print(i)
    print()
    print(f"O Primeiro número da lista vai ser substítuido por {num_troca}")
    lista[0]=troca

lista_num=[]
while True:
        try:
            num=int(input("Digite um número para sua lista (digite -99 para encerrar): "))
            if num==-99:
                print("Lista encerrada.")
                break
            else:
                lista_num.append(num)
                print("Número adicionado")
        except ValueError:
            print("o VALOR Digitado não é válido")  
num_troca=int(input("Digite um número para ser como troca:"))
funct(lista_num,num_troca)
print()
print("Os itens da lista agora é: ")
for i in lista_num:
    print(i)

#ex04
def solicitar_nome():
    name=str(input("Digite o seu nome:"))
    def exibir_nome():
        print(f"Seu nome é {name}")
    return exibir_nome
função_exibir=solicitar_nome()
função_exibir()

#ex05
nome = "Global"
def exibir_variaveis():
    nome = "Local"
    print(f"Valor da variável local: {nome}")
    print(f"Valor da variável global: {globals()['nome']}")
exibir_variaveis()
print(f"Valor da variável global fora da função: {nome}")


#ex06
import math_utils
math_utils.dobro(int(input("Digite o número para ser mostrado o dobro: ")))


#ex07
import string_utils
string_utils.inverter(str(input("Digite a palavra a ser invertida:")))


#ex08
import counter_utils
counter_utils.incrementar(int(input("Digite um número final da contagem:")))


#ex09
import random_utils
numero1=int(input("Digite o número inicial do intervalo: "))
numero2=int(input("Digite o número final do intervalo: "))
random_utils.gerar_numero_aleatorio(numero1,numero2)
'''
#ex10
import data_utils
data_utils.exibir_data_atual()