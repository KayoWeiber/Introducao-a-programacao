
def inverter(string):
    invertida= string[::-1]
    print(invertida)
    