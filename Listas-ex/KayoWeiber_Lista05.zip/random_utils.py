def gerar_numero_aleatorio(num1,num2):
    import random
    #for _ in range(5):    #definir quantidade de número
    numero_aleatorio = random.randint(num1, num2)
    print(f"Número aleatório gerado: {numero_aleatorio}")