def dobro(num):
    dobro_numero=num*2
    print(dobro_numero)