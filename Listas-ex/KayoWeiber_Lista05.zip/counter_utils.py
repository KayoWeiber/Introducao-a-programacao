counter=0
def incrementar(num):
    global counter
    while True:
        if counter<num:
            counter+=1
            def exibir_contagem():
                print(counter)
            exibir_contagem()
        else:
            break